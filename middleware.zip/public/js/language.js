// $(document).ready(function () {
//     var language = $("#language_select").val()
//     alert(language)

//     $(document).on("change", "#language_select", function () {
        
//         var language = $("#language_select").val()
//         var base_url = window.location.origin;

//         $.ajax({
//             url: base_url + "/master_shop/" + language,
//             type: "GET",    
//             dataType: "JSON",
//             success: function (res) {

//             }
//         })
        
//         location.reload();
//     })
  
// })