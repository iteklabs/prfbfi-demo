

(function($) {
  "use strict"
  
  // single select box
  $("#single-select").select2({
    placeholder: 'Search for a repository',
  });

})(jQuery);